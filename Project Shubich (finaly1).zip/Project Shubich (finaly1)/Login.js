let navField = document.querySelector('#nav');
let moneyBag = document.querySelector('#moneyBag');
const form = document.querySelector(".form-1");
const inputs = form.elements;
let incomeForm = document.querySelector('#incomeForm');
let userPutMoney = document.querySelector('#userPutMoney');
let inpAddMoney = document.querySelector('#addedMoney');
let btnAddMoney = document.querySelector('#addMoney');
moneyBagIcon = document.querySelector('#moneyQuantity')
const cleanHistoryIncome = document.querySelector('#cleanHistoryIncome');
let incomeExchangeSelected = document.querySelector('.incomeMoney');
let bankExchangeSelected = document.querySelector('.bankMoney');


const registeredUsers = [
  ["Victor", "123"],
  ["Mariya", "1234"],
  ["Mia", "12345"],
];

function isValid(username, password) {   
  for(var i = 0; i < registeredUsers.length; i++) {
      var temp = registeredUsers[i];
      if (temp[0] == username) {
        var currentPair = temp;
        break;        
      }        
  }     
  if (currentPair && currentPair[1] == password) {
    return true;           
  } else {
    return false;
  }
}

form.addEventListener('submit', function(e){
  e.preventDefault();
  var username = inputs["login"].value;
  var password = inputs["password"].value;  
    if (!isValid(username, password)){ 
        alert('Неверный логин или пароль');       
    } else {      
      btnCategory.style.display = 'block';
        navField.style.display = 'block';
        moneyBag.style.display = 'block';
        form.style.display = 'none';
      getDataIncome();
    }
});

function formIncome(){
  categoryInfo.style.display = 'none';
  expensesInfo.style.display = 'none';
  usersForm.style.display = 'none';
  incomeForm.style.display = 'block';
  userPutMoney.innerHTML = 'Funds deposited by user:' + inputs["login"].value;
}
btnIncome.addEventListener('click', formIncome );

const postDataIncome = () => {
  event.preventDefault();

  function selectIncomeCurrency(){
    if(incomeExchangeSelected.value === 'EUR'){
        incomeEUR = inpAddMoney.value;
        incomeBYN = 0;
        incomeUSD = 0;

    } else if(incomeExchangeSelected.value === 'USD'){
        incomeUSD = inpAddMoney.value;
        incomeBYN = 0;
        incomeEUR = 0;
    } else if(incomeExchangeSelected.value === 'BYN'){
        incomeBYN = inpAddMoney.value;
        incomeEUR = 0;
        incomeUSD = 0;
    }
    }
    selectIncomeCurrency()
 
  fetch('http://localhost:3000/comments', {
      method: 'POST',
      body: JSON.stringify({
          "nameUser": inputs["login"].value,
          "passsword": inputs["password"].value,
          "incomeEUR":incomeEUR,
          "incomeUSD":incomeUSD,
          "incomeBYN":incomeBYN,
          "currency":incomeExchangeSelected.value
      }),
      headers : {
          "Content-type": "application/json; charset=utf-8"
      }
  }).then(
      res => {
          return res.json();
      }
  ).then(
      data =>{
          console.log('POST:', data);
          inpAddMoney.value = 0;
      } 
  )
}


btnAddMoney.addEventListener('click', function(){
  postDataIncome();
  moneyBagIcon.innerHTML = 0;
  setTimeout(getDataIncome, 100) ;
});


const getDataIncome = () => {
   fetch('http://localhost:3000/comments').then(
       (res) =>{
           return res.json()
       }
   ).then(
       (data) =>{ console.log(data)
       data.forEach((post) => {
         if(bankExchangeSelected.value === 'EUR'){
           moneyBagIcon.innerHTML -= (post.incomeEUR)*-1;
       } else if(bankExchangeSelected.value === 'USD'){
           moneyBagIcon.innerHTML -= (post.incomeUSD)*-1; 
       } else if(bankExchangeSelected.value === 'BYN'){
          moneyBagIcon.innerHTML -= (post.incomeBYN)*-1;
       }
    })
       }
     
   ).catch(
       (err) => console.log( 'Error:', err)
   )
}

bankExchangeSelected.addEventListener('change', function (e) {
  moneyBagIcon.innerHTML = 0;
  getDataIncome();
  })

  

const deleteData = () => {
  
  fetch('http://localhost:3000/comments/340', { 
   method: 'DELETE'
}).then(
   res => {
       return res.json();
   }
).then(
   data =>{
       console.log('DELETE:', data);
   }
)
};

cleanHistoryIncome.addEventListener('click', deleteData)







