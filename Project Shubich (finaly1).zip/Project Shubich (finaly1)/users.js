let usersForm = document.querySelector('#users');
let btnUsers = document.querySelector('#nav5');
let listUsers = document.querySelector('#listUsers');
btnCanselFormUser = document.querySelector('#canselFormUser')


function userFormOpen(){
    categoryInfo.style.display = 'none';
    expensesInfo.style.display = 'none';
    incomeForm.style.display = 'none';
    usersForm.style.display = 'block';
  }
  btnUsers.addEventListener('click', userFormOpen );

  function canselFormUser(){
    usersForm.style.display = 'none';
  }
  btnCanselFormUser.addEventListener('click', canselFormUser);


  
  