let moneyBagIcon = document.querySelector('.moneyQuantity');
let categoryInfo = document.querySelector('#infForm');
let btnCategory = document.querySelector('.categories');
let categoryName = document.querySelector('#nameCat');
let canselCategoryInfo = document.querySelector('#canselCatInfo');
let expensesInfo = document.querySelector('#outExpenForm')
let btnExpenses = document.querySelector('#nav1');
let btnIncome = document.querySelector('#nav2');
let btnPriceInf = document.querySelector('#current-totalPrice');
let currentTotalPriceDisplay = document.querySelector('#current-totalPriceDisplay');
let btnLogin = document.querySelector('#btnLog');
let btnEnterInn = document.querySelector('#nav7');
let loginForm = document.querySelector('.form-1');
let btnCalselCategoryInfo = document.querySelector('#btnCanselCategoryInfo');


let inputPrice = document.querySelector('#tp4')

btnCategory.addEventListener('click', function(event){
  expensesInfo.style.display = 'none';
  incomeForm.style.display = 'none';
  if(event.target.classList.contains('button')){
    if(categoryInfo.style.display == 'block'){
      categoryInfo.style.display = 'none';
    }  else {
      categoryInfo.style.display = 'block';
            categoryName.innerText = event.target.innerText}
    }
    }) 

    canselCategoryInfo.addEventListener('click', function(){
      categoryInfo.style.display = 'none';
    })

btnExpenses.addEventListener('click', function(){
  incomeForm.style.display = 'none';
  if(expensesInfo.style.display == 'block'){
    expensesInfo.style.display = 'none';
  }  else {
    expensesInfo.style.display = 'block';
    categoryInfo.style.display = 'none';
  }
})

function canselInfo(){
  expensesInfo.style.display = 'none'

}

 function evPrev(){
  event.preventDefault();

}

btnCalselCategoryInfo.addEventListener('click', canselInfo)









