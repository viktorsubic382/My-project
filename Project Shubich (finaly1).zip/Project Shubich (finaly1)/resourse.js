let totalExpencies = document.querySelector('#current-totalPriceDisplay');
let exchangeSelected = document.querySelector('.select21');
let formCategory = document.querySelector('.selectExpencesCat');
let priceInfOnDate = document.querySelector('#сurrent-periodPriceDisplay');
let btnPeriodExpencies = document.querySelectorAll('#current-periodPrice');
let startDatePurch = document.querySelector('#start');
let endDatePurch = document.querySelector('#end');
let sendInformation = document.querySelector('#sendInfoCat');



const getDataProduct = () => {
       fetch('http://localhost:3000/posts').then(
    (res) =>{
        return res.json()
    }
    ).then(
        (data) =>{

    data.forEach((post) => {
        if(formCategory.value === post.categoryName && exchangeSelected.value === 'EUR'){ 
        totalExpencies.innerHTML -= ((post.priceEUR)*-1);
        btnPriceInf.removeEventListener('click', getDataProduct);
        
                } else if
        (formCategory.value === post.categoryName && exchangeSelected.value === 'USD'){ 
        totalExpencies.innerHTML -= ((post.priceUSD)*-1);
        btnPriceInf.removeEventListener('click', getDataProduct);
       
                } else if
        (formCategory.value === post.categoryName && exchangeSelected.value === 'BYN'){
        totalExpencies.innerHTML -= ((post.priceBYN)*-1);
        btnPriceInf.removeEventListener('click', getDataProduct);
       
            }
        })

        exchangeSelected.addEventListener('change', function (e) {
        totalExpencies.innerHTML = 0;
        btnPriceInf.addEventListener('click', getDataProduct);
            })

        formCategory.addEventListener('change', function (e) {
        totalExpencies.innerHTML = 0;
        btnPriceInf.addEventListener('click', getDataProduct);
            })   

        }

    ).catch( 
        (err) => console.log( 'Error:', err)
    )

}
btnPriceInf.addEventListener('click', getDataProduct);


const postDataProduct = () => {
const nameProduct = document.querySelector('#tp1').value;
const quantityProd = document.querySelector('#tp2').value;
const selectValueInfo = document.querySelector('.select1');
const selectVolume = selectValueInfo.value;
const selectCurrencyInfo = document.querySelector('.select2')
const purchasingDate = document.querySelector('#tp3').value;
const note = document.querySelector('#comment');

    event.preventDefault();
    function selectCurrency(){
        if(selectCurrencyInfo.value === 'EUR'){
            priceProdEUR = document.querySelector('#tp4').value;
            priceProdBYN = 0;
            priceProdUSD = 0;
            

        } else if(selectCurrencyInfo.value === 'USD'){
            priceProdUSD = document.querySelector('#tp4').value;
            priceProdBYN = 0;
            priceProdEUR = 0;
            
        } else if(selectCurrencyInfo.value === 'BYN'){
            priceProdBYN = document.querySelector('#tp4').value;
            priceProdEUR = 0;
            priceProdUSD = 0;
        }
        }
        selectCurrency()

    fetch('http://localhost:3000/posts', {
        method: 'POST',
        body: JSON.stringify({
            "categoryName":categoryName.innerHTML,
            "nameProd": nameProduct,
            "quanProd": quantityProd + " " + selectVolume,
            "purchDate": purchasingDate,
            "priceEUR":priceProdEUR,
            "priceUSD":priceProdUSD,
            "priceBYN":priceProdBYN,
            "currency": selectCurrencyInfo.value,
            "notice": note.value
        }),
        headers : {
            "Content-type": "application/json; charset=utf-8"
        }
    }).then(
        res => {
            return res.json();
        }
    ).then(
        data =>{
            console.log('POST:', data);
        }
    )
   
}
sendInformation.addEventListener('click',postDataProduct );


const deleteDataProduct = () => {
       fetch('http://localhost:3000/posts/15', { 
        method: 'DELETE'
    }).then(
        res => {
            return res.json();
        }
    ).then(
        data =>{
            console.log('DELETE:', data);
        }
    )
};

document.querySelector('#cleanHistory').addEventListener('click', deleteDataProduct)
